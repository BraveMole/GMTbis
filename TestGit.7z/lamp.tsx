<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="lamp" tilewidth="32" tileheight="32" tilecount="72" columns="6">
 <image source="lamp.png" width="200" height="400"/>
</tileset>
