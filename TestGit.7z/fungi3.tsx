<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="fungi3" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="fungi3.png" width="100" height="120"/>
</tileset>
