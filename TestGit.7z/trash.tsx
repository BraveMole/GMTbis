<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="trash" tilewidth="32" tileheight="32" tilecount="36" columns="6">
 <image source="trash.png" width="200" height="200"/>
</tileset>
