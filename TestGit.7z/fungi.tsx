<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="fungi" tilewidth="32" tileheight="32" tilecount="150" columns="30">
 <image source="fungi.png" width="980" height="163"/>
</tileset>
