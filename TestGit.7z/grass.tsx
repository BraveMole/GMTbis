<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="grass" tilewidth="32" tileheight="32" tilecount="14" columns="7">
 <image source="grass.png" width="240" height="80"/>
</tileset>
